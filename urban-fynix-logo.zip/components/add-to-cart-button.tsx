"use client"

import { useState } from "react"
import { ShoppingCart } from "lucide-react"

interface AddToCartButtonProps {
  productId: number
}

export default function AddToCartButton({ productId }: AddToCartButtonProps) {
  const [isAdding, setIsAdding] = useState(false)

  const handleAddToCart = () => {
    setIsAdding(true)

    // Simulate API call
    setTimeout(() => {
      setIsAdding(false)
      // Here you would typically update a cart state or context
      console.log(`Added product ${productId} to cart`)
    }, 1000)
  }

  return (
    <button
      onClick={handleAddToCart}
      disabled={isAdding}
      className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-md transition-colors flex items-center justify-center"
    >
      <ShoppingCart className="h-5 w-5 mr-2" />
      {isAdding ? "Adding..." : "Add to Cart"}
    </button>
  )
}
