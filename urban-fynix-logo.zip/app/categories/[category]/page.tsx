import { notFound } from "next/navigation"
import ProductFilter from "@/components/product-filter"
import ProductCard from "@/components/product-card"

export default function CategoryPage({ params }: { params: { category: string } }) {
  const { category } = params

  // Validate category
  const validCategories = ["tshirts", "hoodies", "accessories"]
  if (!validCategories.includes(category)) {
    notFound()
  }

  // Mock data for products
  const products = [
    {
      id: 1,
      name: "Urban Graphic Tee",
      price: 29.99,
      image: "/placeholder.svg?height=400&width=300",
      category: "tshirts",
      gender: "unisex",
    },
    {
      id: 2,
      name: "Street Style Tee",
      price: 34.99,
      image: "/placeholder.svg?height=400&width=300",
      category: "tshirts",
      gender: "men",
    },
    {
      id: 3,
      name: "Casual Fit Tee",
      price: 27.99,
      image: "/placeholder.svg?height=400&width=300",
      category: "tshirts",
      gender: "women",
    },
    {
      id: 4,
      name: "Vintage Print Tee",
      price: 32.99,
      image: "/placeholder.svg?height=400&width=300",
      category: "tshirts",
      gender: "unisex",
    },
    {
      id: 5,
      name: "Classic Hoodie",
      price: 49.99,
      image: "/placeholder.svg?height=400&width=300",
      category: "hoodies",
      gender: "unisex",
    },
    {
      id: 6,
      name: "Zip-up Hoodie",
      price: 54.99,
      image: "/placeholder.svg?height=400&width=300",
      category: "hoodies",
      gender: "men",
    },
    {
      id: 7,
      name: "Cropped Hoodie",
      price: 47.99,
      image: "/placeholder.svg?height=400&width=300",
      category: "hoodies",
      gender: "women",
    },
    {
      id: 8,
      name: "Urban Backpack",
      price: 39.99,
      image: "/placeholder.svg?height=400&width=300",
      category: "accessories",
      gender: "unisex",
    },
    {
      id: 9,
      name: "Designer Cap",
      price: 24.99,
      image: "/placeholder.svg?height=400&width=300",
      category: "accessories",
      gender: "unisex",
    },
    {
      id: 10,
      name: "Urban Socks",
      price: 12.99,
      image: "/placeholder.svg?height=400&width=300",
      category: "accessories",
      gender: "unisex",
    },
  ].filter((product) => product.category === category)

  // Category titles
  const categoryTitles: { [key: string]: string } = {
    tshirts: "T-Shirts",
    hoodies: "Hoodies",
    accessories: "Accessories",
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row gap-8">
        <div className="w-full md:w-1/4">
          <ProductFilter />
        </div>
        <div className="w-full md:w-3/4">
          <h1 className="text-4xl font-bold mb-8 font-montserrat">{categoryTitles[category]}</h1>
          <p className="text-lg mb-8">Showing {products.length} products</p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
